#include<iostream>

using namespace std;

class binarysearch{
private:
  int i, j, first, last, middle, size, key, *array, temp;

public:
binarysearch()
{
  cout << "\n-------------Welcome to Binary Search Program--------------" << endl;
  i = j = first = last = middle = size = key = temp = 0;
  array = new int[size];
}

void input(){
  cout << "\n-------------------------Input-------------------------\n" << endl;
  cout << "Enter Number of Elements :- " ;
  cin >> size;
  array = new int[size];
  cout << "Enter " << size << " Numbers :- " ;
  for(i = 0; i < size; i++)
    cin >> array[i];
  cout << endl << "The List of Elements Entered by You is :- " ;
  display();
 }

void display(){
  cout << "[" ;
  for(i = 0; i < size; i++) {
    if(i != size - 1) {
    cout << array[i] << ", " ; }
    else {
    cout << array[i] << " ]"; }
  }
}  

void sorting(){
  cout << endl << "------------------------Sorting------------------------" << endl ;
  
   for (i = 0; i < ( size - 1 ); i++) {
     for (j = 0; j < size - i - 1; j++) {
       if (array[j] > array[j+1])
       {
         temp       = array[j];
         array[j]   = array[j+1];
         array[j+1] = temp;
       }
     }
   }
  cout << "The Sorted List of Elements is :- " ;
  display();
}

void searching(){
  cout << endl << "-----------------------Searching-----------------------" << endl ;
  cout << "Enter the Key value to Find : " ;
  cin >> key;
  cout << endl << "-------------------------Result------------------------" << endl ;

  first  = 0;
  last   = size - 1;
  middle = (first + last)/2;
 
    while( first <= last )
    {
      if ( array[middle] < key )
        first = middle+1;    
      else if ( array[middle] == key ) 
      {
        cout << key << " found at location " << middle<< ".\n" ;
        break;
      }
      else
         last = middle - 1;
 
      middle = (first + last)/2;
   }
   if ( first > last )
      cout << key << " is not present in the list.\n" ;
}

};

int main(){
  binarysearch obj;
  obj.input();
  obj.sorting();
  obj.searching();
  return 0;
}

