



import java.io.*;
import java.net.*;
import java.util.*;


public class Client1 {
 
	
	
   public static void main(String argv[])
 
      {  Scanner scaninput = new Scanner(System.in);
	   try{
		    Socket socketClient= new Socket("localhost",5555);
		    System.out.println("Client: "+"Connection Established");
 
		    BufferedReader reader = 
		    		new BufferedReader(new InputStreamReader(socketClient.getInputStream()));
 
		    BufferedWriter writer= 
	        		new BufferedWriter(new OutputStreamWriter(socketClient.getOutputStream()));
		    String serverMsg;
		    
		    
		    System.out.println("Enter the Multiplicand or whatever in decimal");
		    int num1 = scaninput.nextInt();
		    System.out.println("Opposite one in decimal");
		    int num2 = scaninput.nextInt();
		    
		    
		    
		    writer.write(""+num1+"\r\n");
		    writer.write(""+num2+"\r\n");
            writer.flush();
			while((serverMsg = reader.readLine()) != null){
				System.out.println("Client: " + serverMsg);
			}
 
	   }catch(Exception e){e.printStackTrace();}
      }
}

/*Output


C:\Users\Parth\Desktop\booth_new>javac Client1.java

C:\Users\Parth\Desktop\booth_new>javac Client1.java

C:\Users\Parth\Desktop\booth_new>java Client1
Client: Connection Established
Enter the Multiplicand or whatever in decimal
6
Opposite one in decimal
3
Client: Booth Algorithm Assignment
Client:
Client: === Result is  : 18

C:\Users\Parth\Desktop\booth_new>*/