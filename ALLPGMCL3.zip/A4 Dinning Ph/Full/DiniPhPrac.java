/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diniphprac;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import com.mongodb.*;

/**
 *
 * @author Parth
 */
public class DiniPhPrac {

    
    public static void main(String[] args) {
        Lock forks[]=new ReentrantLock[5];
        
        try {
            MongoClient mongoclient=new MongoClient("localhost");
            DB db=mongoclient.getDB("mydb");
            DBCollection collection=db.createCollection("mydb", null);
                    
                    
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        for(int i=0;i<5;i++){
            forks[i]=new ReentrantLock();
        }
        
        Thread p1=new Thread(new Philosopher(forks[4],forks[0],"first"));
        Thread p2=new Thread(new Philosopher(forks[0],forks[1],"second"));
        Thread p3=new Thread(new Philosopher(forks[1],forks[2],"third"));
        Thread p4=new Thread(new Philosopher(forks[2],forks[3],"fourth"));
        Thread p5=new Thread(new Philosopher(forks[3],forks[4],"fifth"));
        p1.start();
        p2.start();
        p3.start();
        p4.start();
        p5.start();
        
        
    }
    
}


