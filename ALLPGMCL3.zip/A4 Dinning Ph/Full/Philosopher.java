/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diniphprac;

import com.mongodb.*;
import com.mongodb.MongoClient;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Parth
 */
public class Philosopher implements Runnable {
    Lock leftFork=new ReentrantLock();
    Lock rightFork=new ReentrantLock();
    String name;
    

    public Philosopher(Lock fork, Lock fork0, String first) {
        this.leftFork=fork;
        this.rightFork=fork0;
        this.name=first;
    }

    @Override
    public void run() {
        think(name);
        try {
            eat(leftFork,rightFork,name);
        } catch (Exception ex) {
            Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            }

    private void think(String name) {
            try {
                MongoClient client=new MongoClient("localhost");
                DB db=client.getDB("mydb");
                DBCollection collection=db.getCollection("mydb");
                BasicDBObject obj=new BasicDBObject(name ," thinking...");
                System.out.println(name+" thinking..");
                collection.insert(obj);
                Thread.sleep(1000);
                
                
        } catch (Exception e) {
                e.printStackTrace();
        }
    }

    private void eat(Lock leftFork, Lock rightFork, String name) throws Exception{
        leftFork.lock();
        rightFork.lock();
        
        try {
            MongoClient client=new MongoClient("localhost");
                DB db=client.getDB("mydb");
                DBCollection collection=db.getCollection("mydb");
                BasicDBObject obj1=new BasicDBObject(name ," eating...");
                System.out.println(name+" eating..");
                collection.insert(obj1);
                Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally{
            MongoClient client=new MongoClient("localhost");
                DB db=client.getDB("mydb");
                DBCollection collection=db.getCollection("mydb");
                BasicDBObject obj2=new BasicDBObject(name ," done with eating and again thinking..");
                System.out.println(name+" done with eat and thinking...");
                collection.insert(obj2);
                leftFork.unlock();
                rightFork.unlock();
            
        }
    }
    
}
