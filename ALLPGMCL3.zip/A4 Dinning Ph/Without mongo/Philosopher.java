/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dinpracticefinal;

//import com.mongodb.BasicDBObject;
//import com.mongodb.DB;
//import com.mongodb.DBCollection;
//import com.mongodb.MongoClient;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Parth
 */
public class Philosopher implements Runnable {
    Lock leftFork=new ReentrantLock();
    Lock rightFork=new ReentrantLock();
    String name;

    public Philosopher(Lock fork, Lock fork0, String first) {
            this.leftFork=fork;
            this.rightFork=fork0;
            this.name=first;
    }
    
    

    @Override
    public void run() {
        think(name);
        try {
            eat(leftFork,rightFork,name);
        } catch (Exception ex) {
            Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void think(String name) {
        
        try {
//            MongoClient cl=new MongoClient("localhost");
//            DB db1=cl.getDB("mydb");
//            DBCollection colle=db1.getCollection("mydb1");
            System.out.println(name+" thinking...");
//            BasicDBObject obj=new BasicDBObject(name,"thinking");
//            colle.insert(obj);
            Thread.sleep(1000);
            
            
        } catch (Exception e) {
          e.printStackTrace();
        }
    }

    private void eat(Lock leftFork, Lock rightFork, String name) throws Exception{
        
        leftFork.lock();
        rightFork.lock();
        
        try {
//            MongoClient cly=new MongoClient("localhost");
//            DB db=cly.getDB("mydb");
//            DBCollection coll=db.getCollection("mydb1");
//            BasicDBObject hh=new BasicDBObject(name," eating...");
            System.out.println(name+"  eating..");
            //coll.insert(hh);
            Thread.sleep(1000);
            
        } catch (Exception e) {
           e.printStackTrace();
        }
        finally{
            System.out.println(name+" done eating and now thinking...");
//            MongoClient cl=new MongoClient("localhost");
//            DB db=cl.getDB("mydb");
//            DBCollection col=db.getCollection("mydb1");
//            BasicDBObject basic=new BasicDBObject(name," done eating and now thinking...");
//            col.insert(basic);
            Thread.sleep(1000);
            leftFork.unlock();
            rightFork.unlock();
        }
    }
    
}
