package com.parth.unadkat.calc_trig;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnadd,btnsub,btnmul,btndiv,btnsin,btncos,btntan,btnsqrt,btnclr,btnms,btnmr;
    public static double memval,ipval;
    EditText et1,et2,etres;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init() {
        btnadd=(Button) findViewById(R.id.plus);
        btnsub=(Button) findViewById(R.id.minus);
        btnmul=(Button) findViewById(R.id.mul);
        btndiv=(Button) findViewById(R.id.div);
        btnsin=(Button) findViewById(R.id.sin);
        btncos=(Button) findViewById(R.id.cos);
        btntan=(Button) findViewById(R.id.tan);
        btnclr=(Button) findViewById(R.id.clr);
        btnmr=(Button) findViewById(R.id.mr);
        btnms=(Button) findViewById(R.id.ms);
        btnsqrt=(Button) findViewById(R.id.sqrt);

        btnadd.setOnClickListener(this);
        btnsub.setOnClickListener(this);
        btnmul.setOnClickListener(this);
        btndiv.setOnClickListener(this);
        btnsin.setOnClickListener(this);
        btncos.setOnClickListener(this);
        btntan.setOnClickListener(this);
        btnsqrt.setOnClickListener(this);
        btnms.setOnClickListener(this);
        btnmr.setOnClickListener(this);
        btnclr.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        et1=(EditText) findViewById(R.id.no1);
        et2=(EditText) findViewById(R.id.no2);
        etres=(EditText) findViewById(R.id.res);
        
        String num1=et1.getText().toString();
        String num2=et2.getText().toString();

        switch (v.getId()){
            case R.id.plus:
                int res=Integer.parseInt(num1) + Integer.parseInt(num2);
                etres.setText(String.valueOf(res));
                break;

            case R.id.minus:
                int res1=Integer.parseInt(num1) - Integer.parseInt(num2);
                etres.setText(String.valueOf(res1));
                break;

            case R.id.mul:
                int res2=Integer.parseInt(num1) * Integer.parseInt(num2);
                etres.setText(String.valueOf(res2));
                break;

            case R.id.div:
                int res3=Integer.parseInt(num1) / Integer.parseInt(num2);
                etres.setText(String.valueOf(res3));
                break;

            case R.id.sin:
                double sin1=Math.sin(Double.parseDouble(num1));
                etres.setText(String.valueOf(sin1));
                break;

            case R.id.cos:
                double cos1=Math.cos(Double.parseDouble(num1));
                etres.setText(String.valueOf(cos1));
                break;

            case R.id.tan:
                double tan1=Math.tan(Double.parseDouble(num1));
                etres.setText(String.valueOf(tan1));
                break;

            case R.id.sqrt:
                double sqrt1=Math.sqrt(Double.parseDouble(num1));
                etres.setText(String.valueOf(sqrt1));
                break;

            case R.id.clr:
                memval=Double.NaN;
                etres.setText("data cleared");
                break;

            case R.id.ms:
                ipval=Double.parseDouble(num1);
                if(Double.isNaN(ipval)){
                    etres.setText("no data");
                }
                else {
                    memval=ipval;
                    etres.setText(String.valueOf(memval));
                }
                break;

            case R.id.mr:
                if(Double.isNaN(memval)){
                    etres.setText("no data");
                }
                else {
                    etres.setText(String.valueOf((int) memval));
                }
                break;

        }
    }
}
