package com.example.parth.bluetoothdemo;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView tv=(TextView)findViewById(R.id.tv1);
        Button bt=(Button)findViewById(R.id.btnon);
        Button bt1=(Button)findViewById(R.id.btnoff);
        Button bt2=(Button)findViewById(R.id.btnvidible);


        final BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        if(adapter==null){
            tv.append("Device not supported");
        }
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!adapter.isEnabled()){
                    Intent i=new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(i,0);
                    Toast.makeText(MainActivity.this, "Turning on bluetooth", Toast.LENGTH_SHORT).show();
                }
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!adapter.isDiscovering()){
                    //making device discoverable
                    Toast.makeText(getApplicationContext(), "making your device discoverable", Toast.LENGTH_SHORT).show();
                    Intent in=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(in,0);
                }
            }
        });
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.disable();
                //turn off blurtooth
                Toast.makeText(MainActivity.this, "Turning off bluetooth", Toast.LENGTH_SHORT).show();
            }
        });


    }
}
