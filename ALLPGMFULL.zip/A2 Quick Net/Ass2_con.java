/* 
Using Divide and Conquer Strategies to design an efficient class for Concurrent Quick Sort and the input
data is stored using XML. Use object oriented software design method and Modelio/ StarUML2.x Tool.
Perform the efficiency comparison with any two software design methods. Use necessary USE-CASE
diagrams and justify its use with the help of mathematical modeling. Implement the design using Scala/
Python/Java/C++.
*/

import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

class Sort extends Thread{
	int arr[];
	int low;
	int high;
	Sort(int arr[], int low, int high){
		this.arr = arr;
		this.high = high;
		this.low = low;
	}
	public  int partition(int arr[], int low, int high){
		int pivot = arr[high];
		//System.out.println(pivot);
		int prev = low-1;

		for(int j = low ; j<=high-1; j++){
			if(arr[j] <= pivot){
				prev++;
				int temp = arr[prev];
				arr[prev]=arr[j];
				arr[j]=temp;
			}
		}
		//System.out.println(pivot);
		int temp = arr[prev+1];
		arr[prev+1]=arr[high];
		arr[high]=temp;
		return (prev+1);
	}
	public  void QuickSort(int arr[], int low, int high){
	if(low < high){
		int mid = partition(arr,low,high);
		Sort s1 = new Sort(arr,low,mid-1);
		s1.start();
		Sort s2 = new Sort(arr,mid+1,high);
		s2.start();

		try{
			s1.join();
			s2.join();
		}
		catch(Exception e){}
		}
	}
	public void run(){
		QuickSort(arr, low, high);
	}
}
public class Ass2_con{
	int arr[];
	int n=0;
	public static void print(String s){
			System.out.print(s);
	}
	public void Input(){
		try{
			File xmlInput = new File("C:\\Users\\Parth\\Desktop\\CL-III -MCA\\A2OK\\input.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlInput);
			// normalize text representation
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("number");
			n = nList.getLength();
			arr = new int[n];
			System.out.println("Size = "+n);
			for(int i=0;i<n;i++){
				Node nd = nList.item(i);
				Element el = (Element) nd;
				arr[i] = Integer.parseInt(el.getElementsByTagName("input").item(0).getTextContent());
			}

		}
		catch(Exception e){}
	}
	public static void main(String args[]){
			Ass2_con a = new Ass2_con();

			a.Input();

			System.out.println("Reading from XML ....");
			try{
			Thread.sleep(3000);
			}
			catch(Exception e){}

			System.out.print("Input Numbers :: ");
			for(int i=0;i<a.n;i++)
				print(a.arr[i] + " ");

			Sort s = new Sort(a.arr, 0, a.n-1);
			s.start();
			try{
			s.join();
			}catch(Exception e){}

			System.out.print("\nOutput Numbers :: ");
			for(int i=0;i<a.n;i++)
				print(a.arr[i] + " ");
			print("\n");
	}	
	}

/*
OUTPUT
frenky@frenky:~/Desktop$ javac Ass2_con.java 
frenky@frenky:~/Desktop$ java Ass2_con 
Size = 10
Reading from XML ....
Input Numbers :: 400 200 100 50 25 12 6 3 1 0 
Output Numbers :: 0 1 3 6 12 25 50 100 200 400 
frenky@frenky:~/Desktop$ 
*/
/*
input.xml

<?xml version="1.0"?>
<sort>
<number>
	<input>400</input>
</number>
<number>
	<input>200</input>	
</number>
<number>
	<input>100</input>
</number>
<number>
	<input>50</input>
</number>
<number>
	<input>25</input>
</number>
<number>
	<input>12</input>
</number>
<number>
	<input>6</input>
</number>
<number>
	<input>3</input>
</number>
<number>
	<input>1</input>
</number>
<number>
	<input>0</input>
</number>
</sort>

*/
